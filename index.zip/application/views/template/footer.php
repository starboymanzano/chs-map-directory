<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="<?= base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?= base_url(); ?>assets/js/jquery.datetimepicker.full.js"></script>
<script src="<?= base_url(); ?>assets/js/custom.js"></script>
<script src="<?= base_url(); ?>assets/js/owl.carousel.min.js"></script>
<script src="<?= base_url(); ?>assets/js/jquery.easing.min.js"></script>
<script src="<?= base_url(); ?>assets/js/jquery.countTo.js"></script>
<script src="<?= base_url(); ?>assets/js/jquery.inview.min.js"></script>
<script src="<?= base_url(); ?>assets/js/lightbox.min.js"></script>
<script src="<?= base_url(); ?>assets/js/wow.min.js"></script>
<script src="<?= base_url(); ?>assets/js/app.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCOwJ0uEC3eSeZQM_EovKWlAMe5j4J5-Fo"></script>
</body>
</html>