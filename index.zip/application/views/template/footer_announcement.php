<script src="<?= base_url(); ?>assets/js/jquery-3.2.1.min.js"></script>
<script src="<?= base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?= base_url(); ?>assets/js/jquery.datetimepicker.full.js"></script>
<script src="<?= base_url(); ?>assets/js/owl.carousel.min.js"></script>
<script src="<?= base_url(); ?>assets/js/jquery.easing.min.js"></script>
<script src="<?= base_url(); ?>assets/js/jquery.countTo.js"></script>
<script src="<?= base_url(); ?>assets/js/jquery.inview.min.js"></script>
<script src="<?= base_url(); ?>assets/js/lightbox.min.js"></script>
<script src="<?= base_url(); ?>assets/js/wow.min.js"></script>
<script src="<?= base_url(); ?>assets/js/app.js"></script>
<script src="<?= base_url(); ?>assets/js/drawer.min.js"></script>
<script src="<?= base_url(); ?>assets/js/threejs/three.min.js"></script>
</html>